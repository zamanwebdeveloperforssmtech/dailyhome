jQuery(document).ready(function() {

Cufon.replace('.blogname h1', { fontFamily: 'Myriad Pro' });
jQuery('.squarebanner li:nth-child(even)').addClass('rbanner');

});