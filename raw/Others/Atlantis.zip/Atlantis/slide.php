<div id="slidearea">
<?php if (function_exists('easing_slider')){ easing_slider(); }; ?> 
</div>